# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

# Will be overwritten by cmake.
__version__ = "2024.5.0.0"
