#!/usr/bin/env python3
"""Runtime-only Whisper batch-consistency reproducer (openvino + numpy ONLY).

Does NOT import openvino_genai. Consumes features_AB.npz produced by whisper_feat_prep.py.
Token ids / suppression are read from the model dir's generation_config.json, so the
script adapts to whatever export is present and reports if it differs from the reference.

Runs the exported whisper-tiny ENCODER + stateful DECODER IR with REAL autoregressive
greedy decoding (no teacher forcing after the initial prompt) in four batch layouts:

    B1 = [A]        AB = [A, B]        BA = [B, A]        AA = [A, A]

For input A it compares, step by step, each batched layout against A@B1:
    raw-logit argmax; selected token (post-suppression, greedy); top-1/top-2 raw values
    and margin; max |raw-logit Δ|; first divergent KV VariableState and its max |Δ|.

Greedy decoding => A's fed history in two layouts stays byte-identical up to and including
the first step whose SELECTED token differs; comparison is exact until then and stops at
the first token divergence, while still reporting raw-logit drift in the steps BEFORE it.

Prints a PASS/FAIL block suitable for a Jira ticket.

Usage:
  python whisper_batch_repro.py --model-dir <dir> --features features_AB.npz [--threads N] [--max-new 200]
"""
import argparse
import json
import platform
import numpy as np
import openvino as ov

# Reference expectations for whisper-tiny multilingual (used to flag export drift).
REF = dict(sot=50258, eos=50257, lang_en=50259, transcribe=50359, no_ts=50363,
           begin_suppress=[220, 50257], n_suppress=88)


def load_token_config(model_dir):
    gc = json.load(open(f"{model_dir}/generation_config.json"))
    cfg = json.load(open(f"{model_dir}/config.json"))
    sot = gc.get("decoder_start_token_id", cfg.get("decoder_start_token_id"))
    eos = gc.get("eos_token_id", cfg.get("eos_token_id"))
    lang_en = gc.get("lang_to_id", {}).get("<|en|>", REF["lang_en"])
    transcribe = gc.get("task_to_id", {}).get("transcribe", REF["transcribe"])
    no_ts = gc.get("no_timestamps_token_id", REF["no_ts"])
    begin_suppress = gc.get("begin_suppress_tokens", REF["begin_suppress"])
    suppress = gc.get("suppress_tokens") or cfg.get("suppress_tokens") or []
    prompt = [sot, lang_en, transcribe, no_ts]
    ident = dict(model_type=cfg.get("model_type"), d_model=cfg.get("d_model"),
                 decoder_layers=cfg.get("decoder_layers"), vocab=cfg.get("vocab_size"),
                 num_mel_bins=cfg.get("num_mel_bins"))
    drift = []
    if sot != REF["sot"] or eos != REF["eos"] or lang_en != REF["lang_en"] \
       or transcribe != REF["transcribe"] or no_ts != REF["no_ts"]:
        drift.append(f"special-token ids differ from reference: prompt={prompt} eos={eos}")
    if len(suppress) != REF["n_suppress"]:
        drift.append(f"suppress_tokens count {len(suppress)} != reference {REF['n_suppress']}")
    return dict(prompt=prompt, eos=eos, begin_suppress=begin_suppress,
                suppress=np.array(suppress, dtype=np.int64), ident=ident, drift=drift)


def greedy_decode(enc_cm, dec_cm, feats, track_rows, tok, max_new):
    """feats:[W,80,3000]; fresh InferRequests; real greedy. Returns {row: [per-step records]}."""
    W = feats.shape[0]
    enc_ir = enc_cm.create_infer_request()
    enc_hidden = np.array(enc_ir.infer({"input_features": feats})[enc_cm.output(0)], dtype=np.float32)

    dec_ir = dec_cm.create_infer_request()
    dec_ir.reset_state()
    beam_idx = np.arange(W, dtype=np.int32)
    supp, beg, eos = tok["suppress"], np.array(tok["begin_suppress"], dtype=np.int64), tok["eos"]
    finished = [False] * W
    out_rows = {r: [] for r in track_rows}

    def masked_argmax(row, step):
        m = row.copy(); m[supp] = -np.inf
        if step == 0:
            m[beg] = -np.inf
        return int(np.argmax(m))

    def rec_row(logits_all, r, step):
        row = logits_all[r, -1, :].astype(np.float32)
        o = np.argpartition(row, -2)[-2:]; o = o[np.argsort(row[o])[::-1]]
        top1, top2 = float(row[o[0]]), float(row[o[1]])
        return {"raw_argmax": int(np.argmax(row)), "selected": masked_argmax(row, step),
                "top1": top1, "top2": top2, "margin": top1 - top2, "logits": row,
                "states": {s.name: np.array(s.state.data[r]) for s in dec_ir.query_state()}}

    def all_selected(logits_all, step):
        return [masked_argmax(logits_all[r, -1, :].astype(np.float32), step) for r in range(W)]

    prompt = np.tile(np.array(tok["prompt"], dtype=np.int64), (W, 1))
    out = dec_ir.infer({"input_ids": prompt, "encoder_hidden_states": enc_hidden, "beam_idx": beam_idx})
    logits_all = np.array(out[dec_cm.output(0)])
    for r in track_rows:
        out_rows[r].append(rec_row(logits_all, r, 0))
    sel = all_selected(logits_all, 0)

    for step in range(1, max_new + 1):
        for r in range(W):
            if sel[r] == eos:
                finished[r] = True
        if all(finished[r] for r in track_rows):
            break
        ids = np.array([[eos if finished[r] else sel[r]] for r in range(W)], dtype=np.int64)
        out = dec_ir.infer({"input_ids": ids, "encoder_hidden_states": enc_hidden, "beam_idx": beam_idx})
        logits_all = np.array(out[dec_cm.output(0)])
        for r in track_rows:
            if not finished[r]:
                out_rows[r].append(rec_row(logits_all, r, step))
        sel = all_selected(logits_all, step)
    return out_rows


def compare(ref, cur):
    rep = {"first_tok_div": None, "first_rawargmax_div": None, "first_kv_div": None,
           "max_logit_absdiff": 0.0, "max_logit_step": -1, "pre_div_max_logit": 0.0,
           "compared_steps": 0, "margin_at_div": None, "min_margin": (float("inf"), -1)}
    for i in range(min(len(ref), len(cur))):
        a, b = ref[i], cur[i]
        if a["margin"] < rep["min_margin"][0]:
            rep["min_margin"] = (a["margin"], i)
        d = float(np.max(np.abs(a["logits"] - b["logits"])))
        if d > rep["max_logit_absdiff"]:
            rep["max_logit_absdiff"] = d; rep["max_logit_step"] = i
        if a["raw_argmax"] != b["raw_argmax"] and rep["first_rawargmax_div"] is None:
            rep["first_rawargmax_div"] = (i, a["raw_argmax"], b["raw_argmax"], d)
        if rep["first_kv_div"] is None:
            for name, av in a["states"].items():
                bv = b["states"].get(name)
                if bv is not None and av.shape == bv.shape and av.size and float(np.max(np.abs(av - bv))) > 0.0:
                    rep["first_kv_div"] = (i, name, float(np.max(np.abs(av - bv)))); break
        rep["compared_steps"] = i + 1
        if a["selected"] != b["selected"]:
            rep["first_tok_div"] = (i, a["selected"], b["selected"], d)
            rep["margin_at_div"] = (a["margin"], b["margin"]); break
        rep["pre_div_max_logit"] = max(rep["pre_div_max_logit"], d)
    return rep


def run(threads, model_dir, feats_npz, max_new):
    core = ov.Core()
    cfg = {"INFERENCE_NUM_THREADS": threads} if threads > 0 else {}
    tok = load_token_config(model_dir)
    enc_cm = core.compile_model(core.read_model(f"{model_dir}/openvino_encoder_model.xml"), "CPU", cfg)
    dec_cm = core.compile_model(core.read_model(f"{model_dir}/openvino_decoder_model.xml"), "CPU", cfg)
    eff = dec_cm.get_property("INFERENCE_NUM_THREADS")

    z = np.load(feats_npz, allow_pickle=True)
    A, B = z["feat_a"].astype(np.float32), z["feat_b"].astype(np.float32)

    ref = greedy_decode(enc_cm, dec_cm, A, [0], tok, max_new)[0]
    ab = greedy_decode(enc_cm, dec_cm, np.concatenate([A, B]), [0], tok, max_new)[0]
    ba = greedy_decode(enc_cm, dec_cm, np.concatenate([B, A]), [1], tok, max_new)[1]
    aa = greedy_decode(enc_cm, dec_cm, np.concatenate([A, A]), [0, 1], tok, max_new)

    comps = {"A@B1 vs A=row0[A,B]": compare(ref, ab),
             "A@B1 vs A=row1[B,A]": compare(ref, ba),
             "A@B1 vs A=row0[A,A]": compare(ref, aa[0]),
             "[A,A] row0 vs row1 (same infer)": compare(aa[0], aa[1])}
    return eff, len(ref), comps, z, tok


def print_report(eff, ref_len, comps, z, tok, ov_ver):
    print("=" * 80)
    print("WHISPER BATCH-CONSISTENCY RUNTIME REPRODUCER (openvino only; no openvino_genai)")
    print(f"OpenVINO : {ov_ver}")
    print(f"Platform : {platform.platform()}   machine={platform.machine()}")
    print(f"Model id : {tok['ident']}")
    print(f"A = {z['a_source']}")
    print(f"B = {z['b_source']}")
    print(f"preproc  : {z['preprocessor']}  feat_sha={z['feat_sha']}")
    print(f"prompt   : {tok['prompt']}  eos={tok['eos']}  suppress={len(tok['suppress'])}  greedy, no teacher-forcing")
    if tok["drift"]:
        print("EXPORT-DRIFT: " + " | ".join(tok["drift"]))
    else:
        print("EXPORT-DRIFT: none (matches whisper-tiny reference token config)")
    print("=" * 80)
    print(f"Effective INFERENCE_NUM_THREADS = {eff}   |   A@B1 generated {ref_len} steps")
    any_tok = False
    for label, r in comps.items():
        tokd = r["first_tok_div"]; raw = r["first_rawargmax_div"]; kv = r["first_kv_div"]
        any_tok = any_tok or (tokd is not None)
        print(f"  {label}")
        print(f"    selected-token divergence : "
              + ("NONE" if tokd is None
                 else f"step {tokd[0]} ref={tokd[1]} cur={tokd[2]} (margins ref={r['margin_at_div'][0]:.3e} cur={r['margin_at_div'][1]:.3e})"))
        print(f"    raw-argmax divergence     : "
              + ("NONE" if raw is None else f"step {raw[0]} ref={raw[1]} cur={raw[2]} logitΔ={raw[3]:.3e}"))
        print(f"    max |raw-logit Δ|         : {r['max_logit_absdiff']:.3e} @step {r['max_logit_step']} "
              f"(drift before any token div: {r['pre_div_max_logit']:.3e})")
        print(f"    closest near-tie (A)      : min top1-top2 margin = {r['min_margin'][0]:.3e} @step {r['min_margin'][1]}")
        print(f"    first divergent KV state  : "
              + ("NONE" if kv is None else f"step {kv[0]} {kv[1]} |Δ|={kv[2]:.3e}"))
        print(f"    compared steps            : {r['compared_steps']}")
    verdict = "FAIL (selected-token divergence for A across batch layouts)" if any_tok \
              else "PASS (A's selected tokens identical across all batch layouts)"
    print("-" * 80)
    print(f"JIRA-SUMMARY threads={eff} : {verdict}")
    print("-" * 80)
    return any_tok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", required=True)
    ap.add_argument("--features", required=True)
    ap.add_argument("--threads", type=int, default=0, help="INFERENCE_NUM_THREADS; 0 = plugin default")
    ap.add_argument("--max-new", type=int, default=200)
    args = ap.parse_args()
    eff, ref_len, comps, z, tok = run(args.threads, args.model_dir, args.features, args.max_new)
    print_report(eff, ref_len, comps, z, tok, ov.get_version())


if __name__ == "__main__":
    main()
