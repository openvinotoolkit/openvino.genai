#!/usr/bin/env python3
"""Preprocessing step for the Whisper batch reproducer (NOT Runtime-only).

Dependencies (only this script needs them): transformers, datasets, librosa/soundfile.
Produces a portable features_AB.npz that the Runtime-only reproducer consumes, so
the core reproducer needs only `openvino` + `numpy`.

A = "medium" long-form input  : distil-whisper/meanwhile  test[0]  (first 30 s window)
B = "short" input             : hf-internal-testing/librispeech_asr_dummy clean/validation[0]

Feature extraction uses WhisperFeatureExtractor.from_pretrained(<model_dir>), i.e. the
exact preprocessor_config.json shipped with the exported model (feature_size=80,
n_fft=400, hop=160, chunk_length=30, sampling_rate=16000, dither=0.0) — identical to
the failing test's pipeline.

Usage:
  python whisper_feat_prep.py --model-dir <converted_models/whisper-tiny> --out features_AB.npz
"""
import argparse
import hashlib
import json
import numpy as np


def load_audio_meanwhile():
    import datasets
    ds = datasets.load_dataset("distil-whisper/meanwhile", split="test", streaming=True)
    ds = ds.cast_column("audio", datasets.Audio(sampling_rate=16000))
    for x in ds:
        return np.asarray(x["audio"]["array"], dtype=np.float32)
    raise RuntimeError("meanwhile dataset yielded no samples")


def load_audio_librispeech():
    import datasets
    ds = datasets.load_dataset("hf-internal-testing/librispeech_asr_dummy", "clean", split="validation")
    ds = ds.cast_column("audio", datasets.Audio(sampling_rate=16000))
    return np.asarray(ds[0]["audio"]["array"], dtype=np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", required=True, help="exported whisper-tiny dir (has preprocessor_config.json)")
    ap.add_argument("--out", default="features_AB.npz")
    args = ap.parse_args()

    from transformers import WhisperFeatureExtractor
    fe = WhisperFeatureExtractor.from_pretrained(args.model_dir)

    a_audio = load_audio_meanwhile()        # 'medium' long-form source (truncated to 30s window 0 by fe)
    b_audio = load_audio_librispeech()      # 'short' distinct source

    # WhisperFeatureExtractor truncates/pads to n_samples (30 s) -> [1, 80, 3000] window 0.
    feat_a = fe(a_audio, sampling_rate=16000, return_tensors="np").input_features.astype(np.float32)
    feat_b = fe(b_audio, sampling_rate=16000, return_tensors="np").input_features.astype(np.float32)

    pp = json.load(open(f"{args.model_dir}/preprocessor_config.json"))
    pp_id = {k: pp.get(k) for k in
             ["feature_size", "n_fft", "hop_length", "chunk_length", "sampling_rate", "dither", "nb_max_frames"]}

    np.savez(
        args.out,
        feat_a=feat_a, feat_b=feat_b,
        a_source="distil-whisper/meanwhile:test[0] (first 30s window; = long_medium first window)",
        b_source="hf-internal-testing/librispeech_asr_dummy:clean/validation[0] (short)",
        a_audio_len=np.int64(a_audio.shape[0]),
        b_audio_len=np.int64(b_audio.shape[0]),
        preprocessor=json.dumps(pp_id),
        feat_sha=hashlib.sha1(feat_a.tobytes() + feat_b.tobytes()).hexdigest(),
    )
    print("wrote", args.out)
    print("  feat_a", feat_a.shape, "feat_b", feat_b.shape)
    print("  preprocessor", pp_id)
    print("  a_audio_len", a_audio.shape[0], "b_audio_len", b_audio.shape[0])
    print("  feat_sha", hashlib.sha1(feat_a.tobytes() + feat_b.tobytes()).hexdigest())


if __name__ == "__main__":
    main()
