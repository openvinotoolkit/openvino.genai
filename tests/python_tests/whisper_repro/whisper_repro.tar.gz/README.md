# Whisper batch-consistency Runtime reproducer (Apple Silicon target)

Standalone OpenVINO **Runtime** check for whether decoding input A alone (B1) yields the
same tokens / logits / KV as decoding A inside a batch of 2 (B2), across row positions and
against a byte-identical duplicate row. **Does not import `openvino_genai`.**

## Files
- `whisper_feat_prep.py` — one-time preprocessing (needs `transformers`, `datasets`,
  `librosa`/`soundfile`). Writes `features_AB.npz`. Run once anywhere; copy the `.npz` to
  the Mac if you don't want these deps there.
- `whisper_batch_repro.py` — the reproducer. **Needs only `openvino` + `numpy`.**
- `features_AB.npz` — precomputed mel features (portable; ~1.9 MB).

## Inputs
- **A** = `distil-whisper/meanwhile` test[0], first 30 s window (= `long_medium`'s first
  window in `test_batch_long_form_shrinking_active_set`; the row that finishes entirely in
  width-2 rounds).
- **B** = `hf-internal-testing/librispeech_asr_dummy` clean/validation[0] (short, distinct).
- Mel features via `WhisperFeatureExtractor.from_pretrained(<model-dir>)` — the exact
  `preprocessor_config.json` of the export (feature_size 80, n_fft 400, hop 160,
  chunk_length 30, sr 16000, dither 0.0). Feature identity is stamped (`feat_sha`).

## Model requirement
Point `--model-dir` at an exported **whisper-tiny** with:
`openvino_encoder_model.xml/.bin`, `openvino_decoder_model.xml/.bin` (stateful merged
decoder), `generation_config.json`, `config.json`, `preprocessor_config.json`.
Token ids + suppression are read from `generation_config.json`; the script prints
`EXPORT-DRIFT` if they differ from the whisper-tiny reference. **Use the same export the
failing CI job uses.** The local export validated here: optimum-intel
`1.27.0.dev0+140e49a`, transformers `4.57.6`; decoder inputs `input_ids[?,?]`,
`encoder_hidden_states[?,?,384]`, `beam_idx[?]`; output `logits[?,?,51865]`; 16
VariableStates (4 layers × {decoder,encoder}×{key,value}).

## Exact Mac commands
```bash
python -m venv ovenv && source ovenv/bin/activate
pip install openvino numpy                       # reproducer core
pip install transformers datasets librosa soundfile   # only for feat prep

# 1) one-time features (skip if copying features_AB.npz from elsewhere)
python whisper_feat_prep.py --model-dir /path/to/whisper-tiny --out features_AB.npz

# 2) reproduce: default threads, then single thread
python whisper_batch_repro.py --model-dir /path/to/whisper-tiny --features features_AB.npz --threads 0
python whisper_batch_repro.py --model-dir /path/to/whisper-tiny --features features_AB.npz --threads 1
```

## Reading the result (per the agreed decision tree)
- **`threads=0` FAIL and `threads=1` PASS** → standalone Runtime reproduction of thread-order
  nondeterminism → **update the existing CPU-plugin (Apple Silicon) ticket** with this data.
- **Both FAIL** → investigate a more general batch-width inconsistency.
- **Both PASS (tokens always match)** → no direct Runtime reproduction of the CI text
  failure; do **not** claim GenAI is at fault without token-level GenAI evidence.

`closest near-tie (A)` vs `max |raw-logit Δ|` tells you how close a flip was: a token flips
only when batching drift at some step exceeds that step's top1−top2 margin.
